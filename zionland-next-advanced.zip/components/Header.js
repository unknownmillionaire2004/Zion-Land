import Link from 'next/link'
export default function Header(){
  return (
    <header className="bg-white shadow sticky top-0 z-40">
      <div className="container px-4 py-3 flex items-center justify-between">
        <div className="flex items-center">
          <div className="w-12 h-12 rounded-lg bg-gradient-to-r from-zion-teal to-zion-navy flex items-center justify-center text-white font-bold mr-3">ZL</div>
          <div>
            <h1 className="text-lg font-bold text-zion-navy">ZION LAND</h1>
            <p className="text-xs text-gray-500">Hyderabad & Telangana</p>
          </div>
        </div>
        <nav className="hidden md:flex space-x-6 text-sm text-gray-700">
          <Link href="/"><a className="hover:text-zion-teal">Home</a></Link>
          <Link href="/admin"><a className="hover:text-zion-teal">Admin</a></Link>
          <Link href="/developer/sample-developer"><a className="hover:text-zion-teal">Developers</a></Link>
        </nav>
        <div className="flex items-center space-x-3">
          <a href="https://wa.me/919515740405" target="_blank" rel="noreferrer" className="bg-zion-teal text-white px-3 py-2 rounded-lg text-sm">WhatsApp</a>
        </div>
      </div>
    </header>
  )
}
