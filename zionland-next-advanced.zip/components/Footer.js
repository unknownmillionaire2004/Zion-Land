export default function Footer(){
  return (
    <footer className="bg-gray-800 text-white py-10 mt-12">
      <div className="container px-4 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div>
          <h4 className="font-bold text-zion-teal mb-2">ZION LAND</h4>
          <p className="text-sm text-gray-300">Real Estate Comparison Platform for Hyderabad & Telangana</p>
        </div>
        <div>
          <h4 className="font-semibold mb-2">Quick Links</h4>
          <ul className="text-sm text-gray-300 space-y-2">
            <li>Kokapet</li>
            <li>Gachibowli</li>
            <li>Shadnagar</li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-2">Contact</h4>
          <p className="text-sm text-gray-300">WhatsApp: +91 95157 40405</p>
        </div>
      </div>
      <div className="text-center text-xs text-gray-400 mt-8">&copy; 2025 ZION LAND</div>
    </footer>
  )
}
