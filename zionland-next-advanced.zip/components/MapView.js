import dynamic from 'next/dynamic'
import 'leaflet/dist/leaflet.css'
import L from 'leaflet'
if (typeof window !== 'undefined') {
  delete L.Icon.Default.prototype._getIconUrl
  L.Icon.Default.mergeOptions({
    iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
    iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
    shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  })
}
const MapContainer = dynamic(()=>import('react-leaflet').then(mod=>mod.MapContainer), {ssr:false})
const TileLayer = dynamic(()=>import('react-leaflet').then(mod=>mod.TileLayer), {ssr:false})
const Marker = dynamic(()=>import('react-leaflet').then(mod=>mod.Marker), {ssr:false})
const Popup = dynamic(()=>import('react-leaflet').then(mod=>mod.Popup), {ssr:false})

export default function MapView({properties=[]}){
  if (typeof window === 'undefined') return null
  return (
    <div className="w-full h-96 rounded-lg overflow-hidden shadow">
      <MapContainer center={[17.3850,78.4867]} zoom={11} style={{height:'100%', width:'100%'}}>
        <TileLayer attribution="&copy; OpenStreetMap contributors" url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        {properties.map(p=>(
          <Marker key={p.id} position={[p.lat,p.lng]}>
            <Popup>
              <div>
                <strong>{p.title}</strong><br/>
                ₹{(p.price/100000).toFixed(2)} Lacs<br/>
                <a href={'/property/'+p.id}>View details</a>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  )
}
