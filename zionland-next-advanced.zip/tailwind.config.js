module.exports = {
  content: ['./pages/**/*.{js,jsx}','./components/**/*.{js,jsx}'],
  theme: { extend: { colors: { 'zion-teal':'#0D9488','zion-navy':'#0A3D62' } } },
  plugins: []
}
