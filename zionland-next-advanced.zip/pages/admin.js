import { useState } from 'react'

export default function Admin(){
  const [msg, setMsg] = useState('')
  async function upload(e){
    e.preventDefault()
    const f = e.target.file.files[0]
    if(!f) return setMsg('Select CSV')
    const form = new FormData()
    form.append('file', f)
    const res = await fetch('/api/upload', { method: 'POST', body: form })
    const j = await res.json()
    setMsg(j.message || 'Done')
  }
  return (
    <div className='container px-4 py-12'>
      <h1 className='text-2xl font-bold mb-4'>Admin — Upload Properties (CSV)</h1>
      <form onSubmit={upload} className='space-y-4'>
        <input name='file' type='file' accept='.csv' />
        <button className='bg-zion-teal text-white px-4 py-2 rounded'>Upload</button>
      </form>
      <p className='mt-4'>{msg}</p>
      <p className='mt-6 text-sm text-gray-500'>Sample CSV: /public/sample/csv/sample_properties.csv</p>
    </div>
  )
}
