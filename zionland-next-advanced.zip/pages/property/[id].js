import fs from 'fs'
import path from 'path'

export default function Property({property}){
  if(!property) return <div className='container px-4 py-8'>Not found</div>
  return (
    <div className='container px-4 py-12'>
      <div className='grid grid-cols-1 md:grid-cols-3 gap-8'>
        <div className='md:col-span-2'>
          <img src={property.image} className='w-full h-80 object-cover rounded' alt={property.title} />
          <h1 className='text-2xl font-bold mt-4'>{property.title}</h1>
          <p className='text-gray-600'>{property.location} • {property.type}</p>
          <p className='mt-4'>{property.developer} • RERA: {property.rera ? 'Yes' : 'No'}</p>
        </div>
        <aside className='bg-white p-6 rounded-lg shadow'>
          <p className='text-xl font-bold'>₹{(property.price/100000).toFixed(2)} Lacs</p>
          <p className='text-sm text-gray-500 mt-2'>Area: {property.area_sqft} sq.ft.</p>
          <a className='mt-4 inline-block bg-zion-teal text-white px-4 py-3 rounded-lg' href='https://wa.me/919515740405'>Contact via WhatsApp</a>
        </aside>
      </div>
    </div>
  )
}

export async function getStaticPaths(){
  const dataPath = path.join(process.cwd(),'data','properties.json')
  const raw = fs.readFileSync(dataPath,'utf-8')
  const properties = JSON.parse(raw)
  const paths = properties.map(p => ({ params: { id: p.id.toString() } }))
  return { paths, fallback: false }
}

export async function getStaticProps({params}){
  const dataPath = path.join(process.cwd(),'data','properties.json')
  const raw = fs.readFileSync(dataPath,'utf-8')
  const properties = JSON.parse(raw)
  const property = properties.find(p => p.id.toString() === params.id)
  return { props: { property } }
}
