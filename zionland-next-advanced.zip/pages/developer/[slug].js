import fs from 'fs'
import path from 'path'
export default function Developer({developer}){
  if(!developer) return <div className='container px-4 py-8'>Not found</div>
  return (
    <div className='container px-4 py-12'>
      <h1 className='text-2xl font-bold mb-4'>{developer.name}</h1>
      <p className='text-gray-600 mb-6'>{developer.description}</p>
      <h3 className='font-semibold mb-2'>Projects</h3>
      <ul className='list-disc pl-6'>
        {developer.projects.map(p=> <li key={p.id}>{p.title} — {p.location}</li>)}
      </ul>
    </div>
  )
}

export async function getStaticPaths(){
  return { paths: [{ params: { slug: 'sample-developer' } }], fallback: false }
}

export async function getStaticProps({params}){
  // sample static developer info
  const developer = {
    slug: params.slug,
    name: 'Sample Developer',
    description: 'Trusted builder with RERA approvals.',
    projects: [{id:1,title:'Project A', location:'Kokapet'},{id:2,title:'Project B', location:'Gachibowli'}]
  }
  return { props: { developer } }
}
