import formidable from 'formidable'
import { parse } from 'csv-parse/sync'
import fs from 'fs'
import path from 'path'

export const config = { api: { bodyParser: false } }

export default async function handler(req,res){
  if(req.method !== 'POST') return res.status(405).json({message:'Method not allowed'})
  const form = new formidable.IncomingForm()
  form.parse(req, (err, fields, files) => {
    if(err) return res.status(500).json({message: err.message})
    const file = files.file
    if(!file) return res.status(400).json({message:'No file'})
    const content = fs.readFileSync(file.filepath, 'utf-8')
    try{
      const records = parse(content, { columns: true, skip_empty_lines: true })
      // write to data/properties.json (append)
      const dataPath = path.join(process.cwd(),'data','properties.json')
      let existing = []
      try{ existing = JSON.parse(fs.readFileSync(dataPath,'utf-8')) }catch(e){}
      // simple mapping: ensure id unique
      let maxId = existing.reduce((m,c)=>Math.max(m, c.id||0), 0)
      records.forEach(r=>{
        maxId += 1
        existing.push({
          id: maxId,
          title: r.title || r.name || 'Untitled',
          price: Number(r.price||0),
          type: r.type || 'Plot',
          location: r.location || '',
          lat: Number(r.lat||0),
          lng: Number(r.lng||0),
          area_sqft: Number(r.area_sqft||0),
          developer: r.developer || '',
          rera: r.rera === 'true' || r.rera === '1',
          image: r.image || ''
        })
      })
      fs.writeFileSync(dataPath, JSON.stringify(existing, null, 2), 'utf-8')
      return res.status(200).json({message: 'Uploaded '+records.length+' records'})
    }catch(e){
      return res.status(500).json({message: e.message})
    }
  })
}
