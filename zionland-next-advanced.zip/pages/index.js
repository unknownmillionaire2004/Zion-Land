import fs from 'fs'
import path from 'path'
import Link from 'next/link'
import dynamic from 'next/dynamic'
import { useState } from 'react'
const MapView = dynamic(()=>import('../components/MapView'), {ssr:false})

export default function Home({properties}){
  const [query, setQuery] = useState('')
  const filtered = properties.filter(p => (p.title+p.location+p.developer).toLowerCase().includes(query.toLowerCase()))
  return (
    <div>
      <section className="bg-gradient-to-r from-zion-navy to-zion-teal text-white py-20">
        <div className="container px-4 text-center">
          <h1 className="text-4xl font-bold mb-3">ZION LAND — Hyderabad Property Finder</h1>
          <p className="max-w-2xl mx-auto mb-6">Compare top RERA projects and plots in Hyderabad & Telangana.</p>
          <div className="max-w-4xl mx-auto bg-white rounded-3xl p-6 shadow-lg">
            <div className="flex gap-3">
              <select className="flex-1 p-3 border rounded-lg">
                <option>Plots</option>
                <option>Apartments</option>
                <option>Villas</option>
              </select>
              <input value={query} onChange={e=>setQuery(e.target.value)} className="flex-2 p-3 border rounded-lg" placeholder="Search by locality / developer / project" />
              <a href="https://wa.me/919515740405" target="_blank" rel="noreferrer" className="bg-zion-teal text-white px-6 py-3 rounded-lg">WhatsApp</a>
            </div>
          </div>
        </div>
      </section>

      <section className="container px-4 py-12">
        <h2 className="text-2xl font-bold mb-6">Map — Hotspots & Listings</h2>
        <MapView properties={properties} />
      </section>

      <section className="container px-4 py-12">
        <h2 className="text-2xl font-bold mb-6">Featured Properties</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {filtered.map(p => (
            <div key={p.id} className="bg-white rounded-xl shadow p-4">
              <img src={p.image} className="w-full h-40 object-cover rounded" alt={p.title} />
              <h3 className="font-bold mt-3 text-zion-navy">{p.title}</h3>
              <p className="text-sm text-gray-500">{p.location} • {p.type}</p>
              <p className="text-lg font-semibold mt-2">₹{(p.price/100000).toFixed(2)} Lacs</p>
              <div className="mt-3 flex gap-2">
                <Link href={'/property/'+p.id} legacyBehavior><a className="px-3 py-2 bg-zion-teal text-white rounded-lg text-sm">View</a></Link>
                <a className="px-3 py-2 border rounded-lg text-sm" href={`https://wa.me/919515740405?text=Hi,%20I'm%20interested%20in%20${encodeURIComponent(p.title)}`} target="_blank" rel="noreferrer">Contact</a>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}

export async function getStaticProps(){
  const dataPath = path.join(process.cwd(),'data','properties.json')
  const raw = fs.readFileSync(dataPath,'utf-8')
  const properties = JSON.parse(raw)
  return { props: { properties } }
}
