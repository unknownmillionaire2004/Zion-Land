const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ['placehold.co','images.unsplash.com','via.placeholder.com','unpkg.com']
  }
}
module.exports = nextConfig
