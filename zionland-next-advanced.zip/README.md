# ZionLand — Advanced Demo
This is an advanced demo Next.js project for your Zion Land real-estate prototype.

Run:

```bash
npm install
npm run dev
```
